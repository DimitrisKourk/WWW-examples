//inline named export 
export const name = "Nick";
export const age = 18;
const message = () => {
    return name + ' is ' + age + 'years old.';
    };

//named export at the bottom
//export {name, age, message};
